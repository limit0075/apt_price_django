import { useState } from "react";
import { AppHeader } from "@/components/AppHeader";
import { AddressSearchMode } from "@/components/AddressSearchMode";
import { FilterSearchMode } from "@/components/FilterSearchMode";
import type { SearchMode } from "@/lib/mockData";

const Index = () => {
  const [mode, setMode] = useState<SearchMode>("address");

  return (
    <div className="min-h-screen bg-background">
      <AppHeader mode={mode} onModeChange={setMode} />

      {/* SEO */}
      <h1 className="sr-only">부동산 실거래가 분석 터미널 — Realty Terminal</h1>

      <main className="mx-auto max-w-[1600px] px-4 py-6 sm:px-6 lg:px-8">
        {/* Page section banner */}
        <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
          <div>
            <div className="font-mono text-[10px] uppercase tracking-[0.22em] text-primary">
              {mode === "address" ? "Address Lookup" : "Filter Discovery"}
            </div>
            <h2 className="mt-1 text-2xl font-semibold tracking-tight">
              {mode === "address"
                ? "단지를 정확히 찾고, 가격을 깊게 분석합니다"
                : "원하는 가격·세대 조건의 단지를 한 번에 찾습니다"}
            </h2>
          </div>
          <div className="flex items-center gap-2 rounded-sm border border-border bg-surface px-3 py-1.5">
            <span className="font-mono text-[10px] uppercase tracking-[0.16em] text-muted-foreground">
              데이터 기간
            </span>
            <span className="font-mono text-[11px] font-semibold">
              2024.10 — 2025.04
            </span>
          </div>
        </div>

        {mode === "address" ? <AddressSearchMode /> : <FilterSearchMode />}
      </main>

      <footer className="mt-12 border-t border-border bg-surface/30 py-6">
        <div className="mx-auto flex max-w-[1600px] flex-wrap items-center justify-between gap-3 px-6">
          <div className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
            Realty Terminal · 국토교통부 실거래가 + KAPT 데이터 기반
          </div>
          <div className="font-mono text-[10px] text-muted-foreground">
            © 2025 · v0.1 prototype
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
