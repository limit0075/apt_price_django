import { useMemo, useState } from "react";
import { ChevronRight, MapPin, Search } from "lucide-react";
import { Panel } from "./Panel";
import { StatTile } from "./StatTile";
import { PriceCharts } from "./PriceCharts";
import { DistrictGauge } from "./DistrictGauge";
import { cn } from "@/lib/utils";
import {
  buildPriceSeries,
  computeDistrictStats,
  formatManwon,
  formatManwonShort,
  MOCK_COMPLEXES,
  mockAddressSearch,
  type AddressCandidate,
  type Complex,
} from "@/lib/mockData";

type Step = 1 | 2 | 3 | 4;

export const AddressSearchMode = () => {
  const [query, setQuery] = useState("반포");
  const [candidates, setCandidates] = useState<AddressCandidate[]>(mockAddressSearch("반포"));
  const [picked, setPicked] = useState<AddressCandidate | null>(null);
  const [complex, setComplex] = useState<Complex | null>(null);
  const [areaFilter, setAreaFilter] = useState<number | null>(null);

  const step: Step = !picked ? 1 : !complex ? 2 : !areaFilter ? 3 : 4;

  const districtComplexes = useMemo(
    () => (picked ? MOCK_COMPLEXES.filter((c) => c.district === picked.district) : []),
    [picked],
  );

  const filteredTrades = useMemo(() => {
    if (!complex) return [];
    return areaFilter
      ? complex.trades.filter((t) => t.area === areaFilter)
      : complex.trades;
  }, [complex, areaFilter]);

  const series = useMemo(() => buildPriceSeries(filteredTrades), [filteredTrades]);
  const aptAvg = useMemo(
    () => (series.length ? Math.round(series.reduce((s, p) => s + p.avg, 0) / series.length) : 0),
    [series],
  );
  const districtStats = useMemo(
    () => (complex ? computeDistrictStats(complex.district, aptAvg) : null),
    [complex, aptAvg],
  );

  const handleSearch = () => {
    setCandidates(mockAddressSearch(query));
    setPicked(null);
    setComplex(null);
    setAreaFilter(null);
  };

  return (
    <div className="grid gap-5 lg:grid-cols-[360px_1fr]">
      {/* LEFT — search funnel */}
      <aside className="space-y-5">
        <Panel tag="STEP 01" title="주소 검색" bodyClassName="p-3">
          <div className="flex items-center gap-2 rounded-sm border border-input-border bg-input px-3 py-2">
            <Search className="h-4 w-4 text-muted-foreground" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSearch()}
              placeholder="도로명·지번·우편번호"
              className="flex-1 bg-transparent text-sm placeholder:text-muted-foreground focus:outline-none"
            />
            <button
              onClick={handleSearch}
              className="rounded-sm bg-primary px-2.5 py-1 font-mono text-[10px] font-semibold uppercase tracking-wider text-primary-foreground transition-snap hover:bg-primary-glow"
            >
              GO
            </button>
          </div>

          <div className="mt-3 max-h-[220px] space-y-1 overflow-y-auto">
            {candidates.map((c) => (
              <button
                key={c.id}
                onClick={() => {
                  setPicked(c);
                  setComplex(null);
                  setAreaFilter(null);
                }}
                className={cn(
                  "group w-full rounded-sm border border-transparent px-3 py-2 text-left transition-snap hover:border-border-strong hover:bg-surface",
                  picked?.id === c.id && "border-primary/40 bg-primary/[0.06]",
                )}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[13px] font-medium">{c.road}</span>
                  <span className="font-mono text-[10px] text-muted-foreground">{c.zip}</span>
                </div>
                <div className="mt-0.5 font-mono text-[10px] text-muted-foreground">
                  지번 · {c.jibun}
                </div>
              </button>
            ))}
            {!candidates.length && (
              <div className="py-8 text-center text-xs text-muted-foreground">
                검색어를 입력하세요
              </div>
            )}
          </div>
        </Panel>

        {picked && (
          <Panel tag="STEP 02" title="단지 선택" subtitle={picked.district} bodyClassName="p-2">
            <div className="max-h-[260px] space-y-1 overflow-y-auto">
              {districtComplexes.map((c) => (
                <button
                  key={c.id}
                  onClick={() => {
                    setComplex(c);
                    setAreaFilter(null);
                  }}
                  className={cn(
                    "flex w-full items-center justify-between rounded-sm px-3 py-2 transition-snap hover:bg-surface",
                    complex?.id === c.id && "bg-primary/[0.08] ring-1 ring-inset ring-primary/30",
                  )}
                >
                  <div className="text-left">
                    <div className="text-[13px] font-medium">{c.name}</div>
                    <div className="font-mono text-[10px] text-muted-foreground">
                      {c.households.toLocaleString()}세대 · {c.buildYear}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-mono text-xs font-semibold">
                      {formatManwonShort(c.recentPrice)}
                    </div>
                    <div className={cn("font-mono text-[10px]", c.monthlyChange >= 0 ? "text-bull" : "text-bear")}>
                      {c.monthlyChange >= 0 ? "▲" : "▼"} {Math.abs(c.monthlyChange).toFixed(1)}%
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </Panel>
        )}

        {complex && (
          <Panel tag="STEP 03" title="전용면적" bodyClassName="p-3">
            <div className="grid grid-cols-3 gap-1.5">
              <button
                onClick={() => setAreaFilter(null)}
                className={cn(
                  "rounded-sm border border-border px-2 py-2 font-mono text-[11px] transition-snap hover:border-primary/40",
                  !areaFilter && "border-primary bg-primary/10 text-primary",
                )}
              >
                전체
              </button>
              {complex.areas.map((a) => (
                <button
                  key={a}
                  onClick={() => setAreaFilter(a)}
                  className={cn(
                    "rounded-sm border border-border px-2 py-2 font-mono text-[11px] transition-snap hover:border-primary/40",
                    areaFilter === a && "border-primary bg-primary/10 text-primary",
                  )}
                >
                  {a.toFixed(2)}㎡
                </button>
              ))}
            </div>
          </Panel>
        )}
      </aside>

      {/* RIGHT — results */}
      <main className="min-w-0 space-y-5">
        {!complex ? (
          <EmptyState step={step} />
        ) : (
          <>
            <ComplexHeader complex={complex} aptAvg={aptAvg} />
            <div className="grid gap-5 xl:grid-cols-[1fr_360px]">
              <PriceCharts complex={complex} />
              {districtStats && (
                <DistrictGauge stats={districtStats} district={complex.district} />
              )}
            </div>
            <RecentTrades complex={complex} trades={filteredTrades.slice(-12).reverse()} />
          </>
        )}
      </main>
    </div>
  );
};

const ComplexHeader = ({ complex, aptAvg }: { complex: Complex; aptAvg: number }) => (
  <Panel bodyClassName="p-5">
    <div className="flex flex-wrap items-start justify-between gap-4">
      <div className="space-y-2">
        <div className="flex items-center gap-2">
          <span className="ticker bg-primary/15 text-primary">APT</span>
          <span className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
            {complex.city} · {complex.district}
          </span>
        </div>
        <h2 className="text-2xl font-semibold tracking-tight">{complex.name}</h2>
        <div className="flex items-center gap-1.5 text-[13px] text-muted-foreground">
          <MapPin className="h-3.5 w-3.5" />
          {complex.road}
        </div>
      </div>
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        <StatTile label="평균가" value={formatManwonShort(aptAvg)} accent large />
        <StatTile
          label="최근 변동"
          value={`${complex.monthlyChange >= 0 ? "+" : ""}${complex.monthlyChange}%`}
          delta={complex.monthlyChange}
        />
        <StatTile label="세대수" value={complex.households.toLocaleString()} hint="가구" />
        <StatTile
          label="주차"
          value={complex.parkingPerHousehold.toFixed(1)}
          hint="대/세대"
        />
      </div>
    </div>
  </Panel>
);

const RecentTrades = ({ complex, trades }: { complex: Complex; trades: Complex["trades"] }) => (
  <Panel tag="LEDGER" title="최근 실거래" subtitle={`${trades.length}건`}>
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-border text-left font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
            <th className="pb-2 pr-4">계약일</th>
            <th className="pb-2 pr-4">전용면적</th>
            <th className="pb-2 pr-4">동</th>
            <th className="pb-2 pr-4 text-center">층</th>
            <th className="pb-2 pl-4 text-right">거래가</th>
          </tr>
        </thead>
        <tbody>
          {trades.map((t, i) => (
            <tr
              key={i}
              className="border-b border-border/50 transition-snap hover:bg-surface"
            >
              <td className="py-2.5 pr-4 font-mono text-[12px]">{t.date}</td>
              <td className="py-2.5 pr-4 font-mono text-[12px]">{t.area.toFixed(2)}㎡</td>
              <td className="py-2.5 pr-4 text-[12px] text-muted-foreground">{t.dong}</td>
              <td className="py-2.5 pr-4 text-center font-mono text-[12px]">{t.floor}</td>
              <td className="py-2.5 pl-4 text-right">
                <span className="font-mono text-[13px] font-semibold text-foreground">
                  {formatManwon(t.price)}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  </Panel>
);

const EmptyState = ({ step }: { step: Step }) => {
  const steps = [
    "도로명·지번·우편번호로 주소를 검색하세요",
    "후보 중에서 정확한 주소를 선택하세요",
    "해당 위치의 단지를 선택하세요",
    "전용면적을 선택하면 결과가 표시됩니다",
  ];
  return (
    <Panel className="bg-grid">
      <div className="flex min-h-[480px] flex-col items-center justify-center px-6 text-center">
        <div className="grid h-14 w-14 place-items-center rounded-full border border-primary/30 bg-primary/10 shadow-glow">
          <Search className="h-6 w-6 text-primary" />
        </div>
        <h3 className="mt-5 text-xl font-semibold tracking-tight">
          주소를 입력해 실거래를 분석하세요
        </h3>
        <p className="mt-2 max-w-md text-sm text-muted-foreground">
          국토교통부 실거래가 + KAPT 단지정보를 매칭해 가격 추이, 면적·구별 비교, 백분위 분석까지 한 화면에 제공합니다.
        </p>

        <ol className="mt-8 space-y-2.5 text-left">
          {steps.map((s, i) => {
            const idx = (i + 1) as Step;
            const active = step === idx;
            const done = step > idx;
            return (
              <li key={i} className="flex items-center gap-3">
                <span
                  className={cn(
                    "grid h-6 w-6 place-items-center rounded-full border font-mono text-[11px]",
                    done && "border-bull/50 bg-bull/10 text-bull",
                    active && "border-primary bg-primary text-primary-foreground shadow-glow",
                    !done && !active && "border-border text-muted-foreground",
                  )}
                >
                  {done ? "✓" : idx}
                </span>
                <span
                  className={cn(
                    "text-sm",
                    active ? "text-foreground" : "text-muted-foreground",
                  )}
                >
                  {s}
                </span>
                {active && <ChevronRight className="h-4 w-4 text-primary" />}
              </li>
            );
          })}
        </ol>
      </div>
    </Panel>
  );
};
