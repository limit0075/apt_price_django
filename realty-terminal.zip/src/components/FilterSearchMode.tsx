import { useMemo, useState } from "react";
import { Building2, Filter, MapPin, SlidersHorizontal } from "lucide-react";
import { Panel } from "./Panel";
import { StatTile } from "./StatTile";
import { cn } from "@/lib/utils";
import {
  formatManwonShort,
  MOCK_COMPLEXES,
  type Complex,
} from "@/lib/mockData";

const PRICE_PRESETS = [
  { label: "10억", value: 100000 },
  { label: "20억", value: 200000 },
  { label: "30억", value: 300000 },
  { label: "50억", value: 500000 },
];

const HOUSEHOLD_PRESETS = [
  { label: "500↑", min: 500 },
  { label: "1,000↑", min: 1000 },
  { label: "2,000↑", min: 2000 },
  { label: "5,000↑", min: 5000 },
];

export const FilterSearchMode = () => {
  const [maxPrice, setMaxPrice] = useState(300000);
  const [minHouseholds, setMinHouseholds] = useState(1000);
  const [districts, setDistricts] = useState<string[]>([]);
  const [selected, setSelected] = useState<Complex | null>(null);

  const allDistricts = useMemo(
    () => Array.from(new Set(MOCK_COMPLEXES.map((c) => c.district))).sort(),
    [],
  );

  const results = useMemo(() => {
    return MOCK_COMPLEXES.filter(
      (c) =>
        c.recentPrice <= maxPrice &&
        c.households >= minHouseholds &&
        (districts.length === 0 || districts.includes(c.district)),
    ).sort((a, b) => b.households - a.households);
  }, [maxPrice, minHouseholds, districts]);

  return (
    <div className="grid gap-5 lg:grid-cols-[300px_1fr]">
      {/* LEFT — Filters */}
      <aside className="space-y-5">
        <Panel tag="FILTER" title="조건 입력" bodyClassName="space-y-5 p-4">
          {/* Max price */}
          <div>
            <div className="mb-2 flex items-center justify-between">
              <label className="font-mono text-[10px] uppercase tracking-[0.16em] text-muted-foreground">
                최대 가격
              </label>
              <span className="font-mono text-[12px] font-semibold text-primary">
                {formatManwonShort(maxPrice)}
              </span>
            </div>
            <input
              type="range"
              min={50000}
              max={600000}
              step={10000}
              value={maxPrice}
              onChange={(e) => setMaxPrice(Number(e.target.value))}
              className="w-full accent-primary"
            />
            <div className="mt-2 flex gap-1">
              {PRICE_PRESETS.map((p) => (
                <button
                  key={p.value}
                  onClick={() => setMaxPrice(p.value)}
                  className={cn(
                    "flex-1 rounded-sm border border-border px-2 py-1 font-mono text-[10px] transition-snap hover:border-primary/40",
                    maxPrice === p.value && "border-primary bg-primary/10 text-primary",
                  )}
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          {/* Min households */}
          <div>
            <div className="mb-2 flex items-center justify-between">
              <label className="font-mono text-[10px] uppercase tracking-[0.16em] text-muted-foreground">
                최소 세대수
              </label>
              <span className="font-mono text-[12px] font-semibold text-primary">
                {minHouseholds.toLocaleString()}↑
              </span>
            </div>
            <input
              type="range"
              min={100}
              max={10000}
              step={100}
              value={minHouseholds}
              onChange={(e) => setMinHouseholds(Number(e.target.value))}
              className="w-full accent-primary"
            />
            <div className="mt-2 flex gap-1">
              {HOUSEHOLD_PRESETS.map((p) => (
                <button
                  key={p.min}
                  onClick={() => setMinHouseholds(p.min)}
                  className={cn(
                    "flex-1 rounded-sm border border-border px-2 py-1 font-mono text-[10px] transition-snap hover:border-primary/40",
                    minHouseholds === p.min && "border-primary bg-primary/10 text-primary",
                  )}
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          {/* District chips */}
          <div>
            <label className="mb-2 block font-mono text-[10px] uppercase tracking-[0.16em] text-muted-foreground">
              구 선택 (선택 안 하면 전체)
            </label>
            <div className="flex flex-wrap gap-1">
              {allDistricts.map((d) => {
                const active = districts.includes(d);
                return (
                  <button
                    key={d}
                    onClick={() =>
                      setDistricts((prev) =>
                        active ? prev.filter((x) => x !== d) : [...prev, d],
                      )
                    }
                    className={cn(
                      "rounded-full border px-2.5 py-1 font-mono text-[10px] transition-snap",
                      active
                        ? "border-primary bg-primary text-primary-foreground"
                        : "border-border text-muted-foreground hover:border-border-strong hover:text-foreground",
                    )}
                  >
                    {d}
                  </button>
                );
              })}
            </div>
          </div>
        </Panel>

        <Panel tag="META" title="조회 결과 요약" bodyClassName="p-3">
          <div className="grid grid-cols-2 gap-2">
            <StatTile label="단지 수" value={results.length.toString()} accent />
            <StatTile
              label="평균 세대"
              value={
                results.length
                  ? Math.round(
                      results.reduce((s, c) => s + c.households, 0) / results.length,
                    ).toLocaleString()
                  : "—"
              }
            />
          </div>
        </Panel>
      </aside>

      {/* RIGHT — Map + List */}
      <main className="min-w-0 space-y-5">
        <div className="grid gap-5 xl:grid-cols-[1.4fr_1fr]">
          <MapView complexes={results} selected={selected} onSelect={setSelected} />
          <ResultList complexes={results} selected={selected} onSelect={setSelected} />
        </div>

        {selected && <DetailPanel complex={selected} />}
      </main>
    </div>
  );
};

/* -------- Mock map (no Leaflet to avoid heavy deps; pseudo coordinate plot) -------- */
const MapView = ({
  complexes,
  selected,
  onSelect,
}: {
  complexes: Complex[];
  selected: Complex | null;
  onSelect: (c: Complex) => void;
}) => {
  // project lat/lng to 0-100% within Seoul bbox
  const minLat = 37.45,
    maxLat = 37.65,
    minLng = 126.85,
    maxLng = 127.18;
  return (
    <Panel
      tag="MAP"
      title="단지 분포"
      subtitle="서울특별시"
      actions={
        <span className="font-mono text-[10px] text-muted-foreground">
          {complexes.length} markers
        </span>
      }
      bodyClassName="p-0"
    >
      <div className="relative h-[420px] overflow-hidden rounded-b-md bg-grid">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/[0.04] via-transparent to-info/[0.04]" />

        {complexes.map((c) => {
          const x = ((c.lng - minLng) / (maxLng - minLng)) * 100;
          const y = (1 - (c.lat - minLat) / (maxLat - minLat)) * 100;
          const isSel = selected?.id === c.id;
          const size = Math.max(10, Math.min(28, c.households / 400));
          return (
            <button
              key={c.id}
              onClick={() => onSelect(c)}
              className="group absolute -translate-x-1/2 -translate-y-1/2"
              style={{ left: `${x}%`, top: `${y}%` }}
            >
              <div
                className={cn(
                  "rounded-full ring-2 ring-background transition-all",
                  isSel
                    ? "bg-primary shadow-glow"
                    : "bg-info/80 hover:bg-primary",
                )}
                style={{ width: size, height: size }}
              />
              <div
                className={cn(
                  "absolute left-1/2 top-full mt-1 -translate-x-1/2 whitespace-nowrap rounded-sm border border-border bg-popover px-2 py-1 font-mono text-[10px] shadow-elegant transition-opacity",
                  isSel ? "opacity-100" : "opacity-0 group-hover:opacity-100",
                )}
              >
                <div className="font-semibold text-foreground">{c.name}</div>
                <div className="text-primary">{formatManwonShort(c.recentPrice)}</div>
              </div>
            </button>
          );
        })}

        <div className="absolute bottom-3 left-3 flex items-center gap-2 rounded-sm border border-border bg-background/80 px-2.5 py-1.5 backdrop-blur-md">
          <MapPin className="h-3 w-3 text-primary" />
          <span className="font-mono text-[10px] text-muted-foreground">
            마커 클릭 → 상세
          </span>
        </div>
      </div>
    </Panel>
  );
};

const ResultList = ({
  complexes,
  selected,
  onSelect,
}: {
  complexes: Complex[];
  selected: Complex | null;
  onSelect: (c: Complex) => void;
}) => (
  <Panel
    tag="LIST"
    title="조건 일치 단지"
    subtitle={`${complexes.length}건`}
    bodyClassName="p-2"
  >
    <div className="max-h-[420px] space-y-1 overflow-y-auto">
      {complexes.length === 0 && (
        <div className="grid h-[380px] place-items-center text-xs text-muted-foreground">
          조건에 맞는 단지가 없습니다
        </div>
      )}
      {complexes.map((c) => (
        <button
          key={c.id}
          onClick={() => onSelect(c)}
          className={cn(
            "w-full rounded-sm border border-transparent px-3 py-2.5 text-left transition-snap hover:border-border-strong hover:bg-surface",
            selected?.id === c.id &&
              "border-primary/40 bg-primary/[0.06]",
          )}
        >
          <div className="flex items-center justify-between">
            <span className="text-[13px] font-semibold">{c.name}</span>
            <span className="font-mono text-[12px] font-semibold text-primary">
              {formatManwonShort(c.recentPrice)}
            </span>
          </div>
          <div className="mt-1 flex items-center justify-between font-mono text-[10px] text-muted-foreground">
            <span>{c.district} · {c.households.toLocaleString()}세대</span>
            <span className={c.monthlyChange >= 0 ? "text-bull" : "text-bear"}>
              {c.monthlyChange >= 0 ? "▲" : "▼"} {Math.abs(c.monthlyChange).toFixed(1)}%
            </span>
          </div>
        </button>
      ))}
    </div>
  </Panel>
);

const DetailPanel = ({ complex }: { complex: Complex }) => (
  <Panel tag="DETAIL" title={complex.name} subtitle={complex.road}>
    <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
      <StatTile label="최근 거래가" value={formatManwonShort(complex.recentPrice)} accent />
      <StatTile
        label="월 변동"
        value={`${complex.monthlyChange >= 0 ? "+" : ""}${complex.monthlyChange}%`}
        delta={complex.monthlyChange}
      />
      <StatTile label="세대수" value={complex.households.toLocaleString()} hint="가구" />
      <StatTile label="준공" value={String(complex.buildYear)} hint="년도" />
    </div>
    <div className="mt-4 flex flex-wrap gap-2">
      {complex.areas.map((a) => (
        <span
          key={a}
          className="rounded-full border border-border bg-surface px-3 py-1 font-mono text-[11px] text-muted-foreground"
        >
          {a.toFixed(2)}㎡
        </span>
      ))}
    </div>
  </Panel>
);
