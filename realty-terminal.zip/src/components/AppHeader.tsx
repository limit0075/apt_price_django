import { Activity, Search } from "lucide-react";
import type { SearchMode } from "@/lib/mockData";

interface AppHeaderProps {
  mode: SearchMode;
  onModeChange: (m: SearchMode) => void;
}

const ticker = [
  { label: "서울 평균", value: "12.4억", change: "+1.8%", up: true },
  { label: "강남구", value: "26.1억", change: "+2.4%", up: true },
  { label: "서초구", value: "28.7억", change: "+3.1%", up: true },
  { label: "송파구", value: "21.5억", change: "+1.2%", up: true },
  { label: "마포구", value: "16.8억", change: "+0.9%", up: true },
  { label: "은평구", value: "10.5억", change: "-0.4%", up: false },
  { label: "강동구", value: "15.8억", change: "+1.2%", up: true },
  { label: "노원구", value: "8.2억", change: "-0.6%", up: false },
];

export const AppHeader = ({ mode, onModeChange }: AppHeaderProps) => {
  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/80 backdrop-blur-xl">
      {/* Top brand row */}
      <div className="flex h-14 items-center justify-between border-b border-border/60 px-6">
        <div className="flex items-center gap-8">
          <div className="flex items-center gap-2.5">
            <div className="relative grid h-8 w-8 place-items-center rounded-sm bg-primary text-primary-foreground shadow-glow">
              <Activity className="h-4 w-4" strokeWidth={2.5} />
            </div>
            <div className="flex flex-col leading-none">
              <span className="font-mono text-[10px] uppercase tracking-[0.22em] text-primary">
                Realty Terminal
              </span>
              <span className="text-[15px] font-semibold tracking-tight">부동산 실거래 분석</span>
            </div>
          </div>

          <nav className="hidden items-center gap-6 md:flex">
            <button
              data-active={mode === "address"}
              onClick={() => onModeChange("address")}
              className="nav-link font-medium"
            >
              주소 검색
            </button>
            <button
              data-active={mode === "filter"}
              onClick={() => onModeChange("filter")}
              className="nav-link font-medium"
            >
              조건 검색
            </button>
            <span className="nav-link cursor-not-allowed opacity-60">주변시설</span>
            <span className="nav-link cursor-not-allowed opacity-60">임장블로그</span>
          </nav>
        </div>

        <div className="flex items-center gap-4">
          <div className="hidden items-center gap-2 rounded-sm border border-border bg-surface px-3 py-1.5 sm:flex">
            <Search className="h-3.5 w-3.5 text-muted-foreground" />
            <span className="font-mono text-[11px] text-muted-foreground">
              ⌘K · 단지명 / 주소
            </span>
          </div>
          <div className="flex items-center gap-2">
            <span className="pulse-dot" />
            <span className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
              Live · 국토부 API
            </span>
          </div>
        </div>
      </div>

      {/* Ticker tape */}
      <div className="relative h-9 overflow-hidden bg-surface">
        <div className="flex h-full animate-ticker items-center gap-10 whitespace-nowrap px-6">
          {[...ticker, ...ticker].map((t, i) => (
            <div key={i} className="flex items-center gap-2 font-mono text-[11px]">
              <span className="text-muted-foreground">{t.label}</span>
              <span className="font-semibold text-foreground">{t.value}</span>
              <span className={t.up ? "text-bull" : "text-bear"}>
                {t.up ? "▲" : "▼"} {t.change}
              </span>
              <span className="text-border-strong">·</span>
            </div>
          ))}
        </div>
        <div className="pointer-events-none absolute inset-y-0 left-0 w-16 bg-gradient-to-r from-background to-transparent" />
        <div className="pointer-events-none absolute inset-y-0 right-0 w-16 bg-gradient-to-l from-background to-transparent" />
      </div>
    </header>
  );
};
